# BoxPvP Utils 1.1.0

Client-side Fabric utility mod for Minecraft 1.21.11.

## Highlights
- Custom animated BoxPvP GUI (not the vanilla options screen).
- Tooltips on modules explaining what each option does.
- Dedicated **Keybinds** section; every BoxPvP keybind starts **UNASSIGNED**.
- `/boxpvp` client command to open the GUI without a default keybind.
- FPS limit presets, FPS Boost, particle control and background FPS throttle.
- Fullbright, custom crosshair, vanilla hitbox rendering and zoom.
- FPS/CPS/Ping/coordinates/keystrokes/armor HUD.
- Drag-and-drop HUD editor.
- Hide Chat toggle.
- Persistent configuration in `config/boxpvp_utils.properties`.

## Build
The included GitHub Actions workflow extracts `boxpvp-utils.zip` and runs `gradle build`, then uploads `build/libs/*.jar` as an artifact.
