# BoxPvP Utils (Fabric 1.21.11)
Compilar: `gradle build` (Java 21, Gradle 9.x) -> build/libs/boxpvp-utils-1.0.0.jar
O sube la carpeta a GitHub: Actions compila el .jar solo (artifact "boxpvp-utils-jar").
Tecla P (configurable en Controles > Varios) o comando /boxhud: HUD ON/OFF
