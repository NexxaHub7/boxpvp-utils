# BoxPvP Utils (Fabric 1.21.11) - todo en un solo .jar
Tecla 1 (configurable en Controles > Key Binds > BoxPvP Utils) abre el menu con toggles:
HUD, CPS, FPS, Ping, Armadura, Sin particulas, FPS Boost, Firework Fixed, 30 FPS sin foco.
Los ajustes se guardan en config/boxpvp_utils.properties.
Incluye texturas ULTRA (bloques 1x1/2x2, items 4x4, sin nubes/lluvia/nieve). La telarana blanca va solo en el texture pack.
Compilar: `gradle build` (Java 21, Gradle 9.2) -> build/libs/boxpvp-utils-1.0.0.jar
