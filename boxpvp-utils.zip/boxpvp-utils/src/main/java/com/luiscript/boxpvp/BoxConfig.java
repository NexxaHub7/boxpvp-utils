package com.luiscript.boxpvp;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class BoxConfig {
    public static boolean hud = true;
    public static boolean cps = true;
    public static boolean fps = true;
    public static boolean ping = true;
    public static boolean armor = true;
    public static boolean boost = true;        // ajustes de rendimiento
    public static boolean noParticles = true;  // cero particulas
    public static boolean fireworkFix = true;  // Firework Fixed
    public static boolean bgThrottle = true;   // 30 FPS con la ventana sin foco

    private BoxConfig() {}

    private static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("boxpvp_utils.properties");
    }

    private static boolean get(Properties p, String key, boolean def) {
        String v = p.getProperty(key);
        return v == null ? def : Boolean.parseBoolean(v);
    }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) {
            p.load(in);
        } catch (IOException e) {
            return;
        }
        hud = get(p, "hud", hud);
        cps = get(p, "cps", cps);
        fps = get(p, "fps", fps);
        ping = get(p, "ping", ping);
        armor = get(p, "armor", armor);
        boost = get(p, "boost", boost);
        noParticles = get(p, "noParticles", noParticles);
        fireworkFix = get(p, "fireworkFix", fireworkFix);
        bgThrottle = get(p, "bgThrottle", bgThrottle);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hud", String.valueOf(hud));
        p.setProperty("cps", String.valueOf(cps));
        p.setProperty("fps", String.valueOf(fps));
        p.setProperty("ping", String.valueOf(ping));
        p.setProperty("armor", String.valueOf(armor));
        p.setProperty("boost", String.valueOf(boost));
        p.setProperty("noParticles", String.valueOf(noParticles));
        p.setProperty("fireworkFix", String.valueOf(fireworkFix));
        p.setProperty("bgThrottle", String.valueOf(bgThrottle));
        try (OutputStream out = Files.newOutputStream(file())) {
            p.store(out, "BoxPvP Utils");
        } catch (IOException ignored) {
        }
    }
}
