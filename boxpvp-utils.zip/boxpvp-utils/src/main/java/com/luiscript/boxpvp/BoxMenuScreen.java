package com.luiscript.boxpvp;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class BoxMenuScreen extends Screen {

    public BoxMenuScreen() {
        super(Component.literal("BoxPvP Utils"));
    }

    private static Component label(String name, BooleanSupplier value) {
        return Component.literal(name + ": " + (value.getAsBoolean() ? "ON" : "OFF"));
    }

    private void toggle(int x, int y, String name, BooleanSupplier get, Consumer<Boolean> set) {
        addRenderableWidget(Button.builder(label(name, get), b -> {
            set.accept(!get.getAsBoolean());
            b.setMessage(label(name, get));
            BoxConfig.save();
        }).bounds(x, y, 150, 20).build());
    }

    @Override
    protected void init() {
        int gap = 10;
        int x1 = this.width / 2 - 150 - gap / 2;
        int x2 = this.width / 2 + gap / 2;
        int y = Math.max(40, this.height / 2 - 85);
        int step = 24;

        toggle(x1, y, "HUD", () -> BoxConfig.hud, v -> BoxConfig.hud = v);
        toggle(x2, y, "CPS", () -> BoxConfig.cps, v -> BoxConfig.cps = v);
        y += step;
        toggle(x1, y, "FPS", () -> BoxConfig.fps, v -> BoxConfig.fps = v);
        toggle(x2, y, "Ping", () -> BoxConfig.ping, v -> BoxConfig.ping = v);
        y += step;
        toggle(x1, y, "Armadura", () -> BoxConfig.armor, v -> BoxConfig.armor = v);
        toggle(x2, y, "Sin particulas", () -> BoxConfig.noParticles, v -> BoxConfig.noParticles = v);
        y += step;
        toggle(x1, y, "FPS Boost", () -> BoxConfig.boost, v -> BoxConfig.boost = v);
        toggle(x2, y, "Firework Fixed", () -> BoxConfig.fireworkFix, v -> BoxConfig.fireworkFix = v);
        y += step;
        toggle(x1, y, "30 FPS sin foco", () -> BoxConfig.bgThrottle, v -> BoxConfig.bgThrottle = v);
        y += step + 6;

        addRenderableWidget(Button.builder(Component.literal("Cerrar"), b -> this.onClose())
                .bounds(this.width / 2 - 75, y, 150, 20).build());
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(this.font, this.title, this.width / 2, 20, 0xFFFFFFFF);
    }
}
