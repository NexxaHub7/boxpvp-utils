package com.luiscript.boxpvp;

import com.mojang.brigadier.Command;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.Minecraft;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.ParticleStatus;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class BoxPvpClient implements ClientModInitializer {

    private static boolean hudEnabled = true;

    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft = false;
    private boolean lastRight = false;

    // Tecla por defecto: P (se puede cambiar en Opciones > Controles > Varios)
    private static KeyMapping toggleKey;

    private static final EquipmentSlot[] ARMOR = {
            EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET
    };

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils.toggle_hud", GLFW.GLFW_KEY_P, KeyMapping.Category.MISC));

        // Rendimiento: se aplica una vez al iniciar el cliente
        ClientLifecycleEvents.CLIENT_STARTED.register(this::optimize);

        // CPS: se detecta el flanco de pulsación del ratón cada tick
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);

        // HUD
        HudRenderCallback.EVENT.register(this::render);

        // /boxhud -> activa/desactiva el HUD
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("boxhud").executes(ctx -> {
                    hudEnabled = !hudEnabled;
                    ctx.getSource().sendFeedback(Component.literal(
                            "BoxPvP HUD: " + (hudEnabled ? "ON" : "OFF")));
                    return Command.SINGLE_SUCCESS;
                })));
    }

    private void optimize(Minecraft mc) {
        mc.options.particles().set(ParticleStatus.MINIMAL);
        mc.options.entityShadows().set(false);
        mc.options.save();
    }

    private void tick(Minecraft mc) {
        while (toggleKey.consumeClick()) {
            hudEnabled = !hudEnabled;
            if (mc.player != null) {
                mc.player.displayClientMessage(
                        Component.literal("BoxPvP HUD: " + (hudEnabled ? "ON" : "OFF")), true);
            }
        }

        if (mc.getWindow() == null) return;
        long now = System.currentTimeMillis();
        long handle = mc.getWindow().getWindow();

        boolean left = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_LEFT) == GLFW.GLFW_PRESS;
        boolean right = GLFW.glfwGetMouseButton(handle, GLFW.GLFW_MOUSE_BUTTON_RIGHT) == GLFW.GLFW_PRESS;

        if (mc.screen == null) {
            if (left && !lastLeft) leftClicks.addLast(now);
            if (right && !lastRight) rightClicks.addLast(now);
        }
        lastLeft = left;
        lastRight = right;

        while (!leftClicks.isEmpty() && now - leftClicks.peekFirst() > 1000) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now - rightClicks.peekFirst() > 1000) rightClicks.removeFirst();
    }

    private void render(GuiGraphics g, net.minecraft.client.DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (!hudEnabled || mc.player == null || mc.options.hideGui) return;

        int x = 6;
        int y = 6;
        int white = 0xFFFFFFFF;

        g.drawString(mc.font, "CPS: " + leftClicks.size() + " | " + rightClicks.size(), x, y, white);
        y += 11;
        g.drawString(mc.font, "FPS: " + mc.getFps(), x, y, white);
        y += 11;

        PlayerInfo info = mc.getConnection() != null
                ? mc.getConnection().getPlayerInfo(mc.player.getUUID()) : null;
        if (info != null) {
            g.drawString(mc.font, "Ping: " + info.getLatency() + " ms", x, y, white);
            y += 11;
        }

        y += 4;
        Player p = mc.player;
        for (EquipmentSlot slot : ARMOR) {
            ItemStack stack = p.getItemBySlot(slot);
            if (stack.isEmpty()) continue;
            g.renderItem(stack, x, y);
            if (stack.isDamageableItem()) {
                int left = stack.getMaxDamage() - stack.getDamageValue();
                int color = left < stack.getMaxDamage() * 0.2 ? 0xFFFF5555 : white;
                g.drawString(mc.font, String.valueOf(left), x + 20, y + 4, color);
            }
            y += 18;
        }
    }
}
