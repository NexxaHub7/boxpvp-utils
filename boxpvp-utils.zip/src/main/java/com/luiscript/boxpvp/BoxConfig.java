package com.luiscript.boxpvp;

import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

public final class BoxConfig {
    public static boolean hud = true;
    public static boolean cps = true;
    public static boolean fps = true;
    public static boolean ping = true;
    public static boolean armor = true;
    public static boolean boost = true;
    public static boolean noParticles = false;
    public static boolean fireworkFix = true;
    public static boolean bgThrottle = true;
    public static boolean fullbright = false;
    public static boolean hideChat = false;
    public static boolean customCrosshair = true;
    public static boolean hitboxes = false;
    public static boolean lowFire = true;
    public static boolean noVignette = false;
    public static boolean noWeather = false;
    public static boolean noClouds = false;
    public static boolean zoom = false;
    public static boolean fpsGraph = false;
    public static boolean coords = true;
    public static boolean keystrokes = false;
    public static int fpsLimit = 0; // 0 = unlimited
    public static int crosshairSize = 7;
    public static int crosshairGap = 3;
    public static int hudScale = 100;
    public static int hudX = 8;
    public static int hudY = 8;

    private BoxConfig() {}

    private static Path file() { return FabricLoader.getInstance().getConfigDir().resolve("boxpvp_utils.properties"); }
    private static boolean get(Properties p, String k, boolean d) { return p.containsKey(k) ? Boolean.parseBoolean(p.getProperty(k)) : d; }
    private static int getInt(Properties p, String k, int d) { try { return Integer.parseInt(p.getProperty(k)); } catch (Exception e) { return d; } }

    public static void load() {
        Properties p = new Properties();
        try (InputStream in = Files.newInputStream(file())) { p.load(in); } catch (IOException ignored) { return; }
        hud=get(p,"hud",hud); cps=get(p,"cps",cps); fps=get(p,"fps",fps); ping=get(p,"ping",ping); armor=get(p,"armor",armor);
        boost=get(p,"boost",boost); noParticles=get(p,"noParticles",noParticles); fireworkFix=get(p,"fireworkFix",fireworkFix); bgThrottle=get(p,"bgThrottle",bgThrottle);
        fullbright=get(p,"fullbright",fullbright); hideChat=get(p,"hideChat",hideChat); customCrosshair=get(p,"customCrosshair",customCrosshair);
        hitboxes=get(p,"hitboxes",hitboxes); lowFire=get(p,"lowFire",lowFire); noVignette=get(p,"noVignette",noVignette); noWeather=get(p,"noWeather",noWeather);
        noClouds=get(p,"noClouds",noClouds); zoom=get(p,"zoom",zoom); fpsGraph=get(p,"fpsGraph",fpsGraph); coords=get(p,"coords",coords); keystrokes=get(p,"keystrokes",keystrokes);
        fpsLimit=getInt(p,"fpsLimit",fpsLimit); crosshairSize=getInt(p,"crosshairSize",crosshairSize); crosshairGap=getInt(p,"crosshairGap",crosshairGap);
        hudScale=getInt(p,"hudScale",hudScale); hudX=getInt(p,"hudX",hudX); hudY=getInt(p,"hudY",hudY);
    }

    public static void save() {
        Properties p = new Properties();
        p.setProperty("hud",String.valueOf(hud)); p.setProperty("cps",String.valueOf(cps)); p.setProperty("fps",String.valueOf(fps)); p.setProperty("ping",String.valueOf(ping)); p.setProperty("armor",String.valueOf(armor));
        p.setProperty("boost",String.valueOf(boost)); p.setProperty("noParticles",String.valueOf(noParticles)); p.setProperty("fireworkFix",String.valueOf(fireworkFix)); p.setProperty("bgThrottle",String.valueOf(bgThrottle));
        p.setProperty("fullbright",String.valueOf(fullbright)); p.setProperty("hideChat",String.valueOf(hideChat)); p.setProperty("customCrosshair",String.valueOf(customCrosshair)); p.setProperty("hitboxes",String.valueOf(hitboxes));
        p.setProperty("lowFire",String.valueOf(lowFire)); p.setProperty("noVignette",String.valueOf(noVignette)); p.setProperty("noWeather",String.valueOf(noWeather)); p.setProperty("noClouds",String.valueOf(noClouds));
        p.setProperty("zoom",String.valueOf(zoom)); p.setProperty("fpsGraph",String.valueOf(fpsGraph)); p.setProperty("coords",String.valueOf(coords)); p.setProperty("keystrokes",String.valueOf(keystrokes));
        p.setProperty("fpsLimit",String.valueOf(fpsLimit)); p.setProperty("crosshairSize",String.valueOf(crosshairSize)); p.setProperty("crosshairGap",String.valueOf(crosshairGap)); p.setProperty("hudScale",String.valueOf(hudScale)); p.setProperty("hudX",String.valueOf(hudX)); p.setProperty("hudY",String.valueOf(hudY));
        try { Files.createDirectories(file().getParent()); try (OutputStream out=Files.newOutputStream(file())) { p.store(out,"BoxPvP Utils"); } } catch (IOException ignored) {}
    }
}
