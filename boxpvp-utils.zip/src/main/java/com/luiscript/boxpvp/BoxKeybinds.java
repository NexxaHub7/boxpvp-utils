package com.luiscript.boxpvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.KeyMapping;
import org.lwjgl.glfw.GLFW;

import java.util.LinkedHashMap;
import java.util.Map;

public final class BoxKeybinds {
    public static final KeyMapping FULLBRIGHT;
    public static final KeyMapping HIDE_CHAT;
    public static final KeyMapping CROSSHAIR;
    public static final KeyMapping HITBOXES;
    public static final KeyMapping FPS_BOOST;
    public static final KeyMapping HUD_EDITOR;
    public static final KeyMapping SHOW_HUD;
    public static final KeyMapping ZOOM;
    public static final KeyMapping PARTICLES;
    public static final KeyMapping NO_WEATHER;
    public static final KeyMapping NO_VIGNETTE;
    public static final KeyMapping MENU;

    private static final Map<String, KeyMapping> ALL = new LinkedHashMap<>();
    private static boolean registered;

    private static KeyMapping add(String id, String name, KeyMapping.Category category) {
        KeyMapping k = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.boxpvp_utils." + id,
                InputConstants.Type.KEYSYM,
                InputConstants.UNKNOWN.getValue(),
                category));
        ALL.put(name, k);
        return k;
    }

    static {
        KeyMapping.Category cat = KeyMapping.Category.register(
                net.minecraft.resources.Identifier.fromNamespaceAndPath("boxpvp_utils", "keybinds"));
        FULLBRIGHT = add("fullbright", "Fullbright", cat);
        HIDE_CHAT = add("hide_chat", "Ocultar chat", cat);
        CROSSHAIR = add("crosshair", "Custom Crosshair", cat);
        HITBOXES = add("hitboxes", "Hitboxes", cat);
        FPS_BOOST = add("fps_boost", "FPS Boost", cat);
        HUD_EDITOR = add("hud_editor", "HUD Editor", cat);
        SHOW_HUD = add("show_hud", "HUD", cat);
        ZOOM = add("zoom", "Zoom", cat);
        PARTICLES = add("particles", "Particulas", cat);
        NO_WEATHER = add("weather", "Clima", cat);
        NO_VIGNETTE = add("vignette", "Vignette", cat);
        MENU = add("menu", "Menu BoxPvP", cat);
    }

    private BoxKeybinds() {}

    public static Map<String, KeyMapping> all() { return ALL; }

    public static void resetAll() {
        for (KeyMapping k : ALL.values()) k.setKey(InputConstants.UNKNOWN);
    }
}
