package com.luiscript.boxpvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Tooltip;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.KeyEvent;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;

public class BoxMenuScreen extends Screen {
    private enum Page { PERFORMANCE, PVP, VISUAL, HUD, KEYBINDS, SETTINGS }
    private Page page=Page.PERFORMANCE;
    private float open=0f;
    private int waiting=-1;
    private final List<Button> keyButtons=new ArrayList<>();

    public BoxMenuScreen(){super(Component.literal("BoxPvP Utils"));}
    @Override protected void init(){ build(); }
    private void build(){ clearWidgets(); keyButtons.clear();
        int side=125; int top=38;
        nav("⚡ Performance",10,top,side,Page.PERFORMANCE,"Optimiza opciones visuales y limita FPS.");
        nav("🎯 PvP",10,top+28,side,Page.PVP,"HUD y utilidades de combate informativas.");
        nav("👁 Visual",10,top+56,side,Page.VISUAL,"Controles visuales como Fullbright y crosshair.");
        nav("📊 HUD",10,top+84,side,Page.HUD,"Configura y mueve elementos del HUD.");
        nav("⌨ Keybinds",10,top+112,side,Page.KEYBINDS,"Asigna teclas personalizadas. Todas empiezan sin tecla.");
        nav("⚙ Settings",10,top+140,side,Page.SETTINGS,"Configuración general del mod.");
        addRenderableWidget(Button.builder(Component.literal("Cerrar"),b->onClose()).bounds(10,height-35,side,22).build());
        int px=155, py=48, w=Math.min(430,width-px-20);
        if(page==Page.PERFORMANCE) performance(px,py,w);
        else if(page==Page.PVP) pvp(px,py,w);
        else if(page==Page.VISUAL) visual(px,py,w);
        else if(page==Page.HUD) hud(px,py,w);
        else if(page==Page.KEYBINDS) keybinds(px,py,w);
        else settings(px,py,w);
    }
    private void nav(String text,int x,int y,int w,Page target,String tip){Button b=Button.builder(Component.literal(text),z->{page=target;build();}).bounds(x,y,w,22).build();b.setTooltip(Tooltip.create(Component.literal(tip)));addRenderableWidget(b);}
    private void title(GuiGraphics g,String t,String sub,int x,int y){g.drawString(font,t,x,y,0xFFFFFFFF);g.drawString(font,sub,x,y+14,0xFF8D96A8);}
    private void toggle(int x,int y,int w,String name,String desc,BooleanSupplier get,Consumer<Boolean> set){Button b=Button.builder(Component.literal(name+"  "+(get.getAsBoolean()?"ON":"OFF")),z->{set.accept(!get.getAsBoolean());BoxConfig.save();build();}).bounds(x,y,w,24).build();b.setTooltip(Tooltip.create(Component.literal(desc)));addRenderableWidget(b);}
    private void cycle(int x,int y,int w,String name,String desc,int[] values,java.util.function.IntSupplier get,Consumer<Integer> set){int cur=get.getAsInt(), idx=0;for(int i=0;i<values.length;i++)if(values[i]==cur)idx=i;final int next=values[(idx+1)%values.length];Button b=Button.builder(Component.literal(name+": "+(cur==0?"Unlimited":cur)),z->{set.accept(next);BoxConfig.save();build();}).bounds(x,y,w,24).build();b.setTooltip(Tooltip.create(Component.literal(desc)));addRenderableWidget(b);}
    private void performance(int x,int y,int w){title(null,"⚡ Performance","Rendimiento y estabilidad",x,y);y+=35;toggle(x,y,w,"FPS Boost","Aplica ajustes de rendimiento de Minecraft.",()->BoxConfig.boost,v->BoxConfig.boost=v);y+=30;cycle(x,y,w,"FPS Limit","Límite máximo de FPS. 0 = ilimitado.",new int[]{0,30,60,75,120,144,165,240,360},()->BoxConfig.fpsLimit,v->BoxConfig.fpsLimit=v);y+=30;toggle(x,y,w,"Particles","Reduce o elimina las partículas.",()->BoxConfig.noParticles,v->BoxConfig.noParticles=v);y+=30;toggle(x,y,w,"Clouds OFF","Desactiva las nubes para reducir carga visual.",()->BoxConfig.noClouds,v->BoxConfig.noClouds=v);y+=30;toggle(x,y,w,"Weather OFF","Oculta visualmente el clima.",()->BoxConfig.noWeather,v->BoxConfig.noWeather=v);y+=30;toggle(x,y,w,"Background Throttle","Reduce a 30 FPS cuando la ventana pierde foco.",()->BoxConfig.bgThrottle,v->BoxConfig.bgThrottle=v);}
    private void pvp(int x,int y,int w){title(null,"🎯 PvP","Utilidades informativas y de pantalla",x,y);y+=35;toggle(x,y,w,"CPS Counter","Muestra clics por segundo de ataque/uso.",()->BoxConfig.cps,v->BoxConfig.cps=v);y+=30;toggle(x,y,w,"FPS Counter","Muestra los FPS actuales.",()->BoxConfig.fps,v->BoxConfig.fps=v);y+=30;toggle(x,y,w,"Ping","Muestra la latencia del jugador.",()->BoxConfig.ping,v->BoxConfig.ping=v);y+=30;toggle(x,y,w,"Coordinates","Muestra XYZ actuales.",()->BoxConfig.coords,v->BoxConfig.coords=v);y+=30;toggle(x,y,w,"Keystrokes","Muestra W/A/S/D en el HUD.",()->BoxConfig.keystrokes,v->BoxConfig.keystrokes=v);y+=30;toggle(x,y,w,"Hitboxes","Muestra hitboxes vanilla del cliente.",()->BoxConfig.hitboxes,v->BoxConfig.hitboxes=v);}
    private void visual(int x,int y,int w){title(null,"👁 Visual","Personaliza la imagen sin ventajas automáticas de combate",x,y);y+=35;toggle(x,y,w,"Fullbright","Sube el gamma para iluminar zonas oscuras.",()->BoxConfig.fullbright,v->BoxConfig.fullbright=v);y+=30;toggle(x,y,w,"Custom Crosshair","Reemplaza el punto de mira por uno configurable.",()->BoxConfig.customCrosshair,v->BoxConfig.customCrosshair=v);y+=30;cycle(x,y,w,"Crosshair Size","Tamaño del crosshair.",new int[]{3,5,7,9,11},()->BoxConfig.crosshairSize,v->BoxConfig.crosshairSize=v);y+=30;cycle(x,y,w,"Crosshair Gap","Separación del crosshair.",new int[]{1,2,3,4,5,6},()->BoxConfig.crosshairGap,v->BoxConfig.crosshairGap=v);y+=30;toggle(x,y,w,"Low Fire","Reduce visualmente el fuego en primera persona.",()->BoxConfig.lowFire,v->BoxConfig.lowFire=v);y+=30;toggle(x,y,w,"No Vignette","Desactiva el efecto de viñeta del HUD.",()->BoxConfig.noVignette,v->BoxConfig.noVignette=v);y+=30;toggle(x,y,w,"Zoom","Activa un FOV reducido mientras está activo.",()->BoxConfig.zoom,v->BoxConfig.zoom=v);}
    private void hud(int x,int y,int w){title(null,"📊 HUD","Editor y elementos del HUD",x,y);y+=35;toggle(x,y,w,"HUD Master","Muestra u oculta todo el HUD de BoxPvP.",()->BoxConfig.hud,v->BoxConfig.hud=v);y+=30;addRenderableWidget(Button.builder(Component.literal("Abrir HUD Editor"),b->minecraft.setScreen(new HudEditorScreen())).bounds(x,y,w,24).build());y+=34;cycle(x,y,w,"HUD Scale","Escala visual del HUD.",new int[]{75,85,100,115,130,150},()->BoxConfig.hudScale,v->BoxConfig.hudScale=v);y+=30;toggle(x,y,w,"Armor HUD","Muestra la armadura y durabilidad.",()->BoxConfig.armor,v->BoxConfig.armor=v);y+=30;toggle(x,y,w,"Hide Chat","Oculta el chat visualmente.",()->BoxConfig.hideChat,v->BoxConfig.hideChat=v);}
    private void keybinds(int x,int y,int w){title(null,"⌨ Keybinds","Todos empiezan como UNASSIGNED",x,y);y+=34;int i=0;for(Map.Entry<String,net.minecraft.client.KeyMapping> e:BoxKeybinds.all().entrySet()){final int index=i;Button b=Button.builder(Component.literal(e.getKey()+"  [ "+(waiting==index?"Press a key...":e.getValue().getTranslatedKeyMessage().getString())+" ]"),z->{waiting=index;build();}).bounds(x,y,w,23).build();b.setTooltip(Tooltip.create(Component.literal("Click para asignar una tecla. ESC la deja sin asignar.")));addRenderableWidget(b);keyButtons.add(b);y+=27;i++;if(y>height-55)break;}addRenderableWidget(Button.builder(Component.literal("Reset all keybinds"),b->{BoxKeybinds.resetAll();waiting=-1;BoxConfig.save();build();}).bounds(x,y,w/2-4,23).build());addRenderableWidget(Button.builder(Component.literal("Unassign all"),b->{for(net.minecraft.client.KeyMapping k:BoxKeybinds.all().values())k.setKey(InputConstants.UNKNOWN);waiting=-1;build();}).bounds(x+w/2+4,y,w/2-4,23).build());}
    private void settings(int x,int y,int w){title(null,"⚙ Settings","Configuración general",x,y);y+=35;toggle(x,y,w,"Animations","Animaciones de apertura y hover.",()->true,v->{});y+=30;toggle(x,y,w,"Tooltips","Cada módulo muestra para qué sirve al pasar el mouse.",()->true,v->{});y+=30;addRenderableWidget(Button.builder(Component.literal("Reset BoxPvP settings"),b->{BoxConfig.hud=true;BoxConfig.cps=true;BoxConfig.fps=true;BoxConfig.ping=true;BoxConfig.armor=true;BoxConfig.boost=true;BoxConfig.fpsLimit=0;BoxConfig.save();build();}).bounds(x,y,w,24).build());}
    @Override public boolean keyPressed(KeyEvent event){int key=event.key();if(waiting>=0){net.minecraft.client.KeyMapping k=BoxKeybinds.all().values().toArray(new net.minecraft.client.KeyMapping[0])[waiting];if(key==GLFW.GLFW_KEY_ESCAPE||key==GLFW.GLFW_KEY_UNKNOWN){k.setKey(InputConstants.UNKNOWN);}else{k.setKey(InputConstants.Type.KEYSYM.getOrCreate(key));}waiting=-1;build();return true;}return super.keyPressed(event);}
    @Override public void render(GuiGraphics g,int mx,int my,float delta){g.fill(0,0,width,height,0xB0080A0F);open=Math.min(1f,open+delta*0.08f);int px=(int)(8*(1-open));g.fill(6+px,10,width-6,height-6,0xF0141720);g.fill(6+px,10,6+px+125,height-6,0xFF10131A);g.drawString(font,"BOXPVP",18+px,18,0xFF66CCFF);g.drawString(font,"UTILS",18+px,29,0xFF9BA4B4);super.render(g,mx,my,delta);}
    @Override public void renderBackground(GuiGraphics g,int mx,int my,float delta){}
}
