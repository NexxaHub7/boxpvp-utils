package com.luiscript.boxpvp;

import com.mojang.blaze3d.platform.InputConstants;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.DeltaTracker;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.multiplayer.PlayerInfo;
import net.minecraft.client.KeyMapping;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.ChatVisiblity;
import net.minecraft.resources.Identifier;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayDeque;
import java.util.Deque;

public class BoxPvpClient implements ClientModInitializer {
    private final Deque<Long> leftClicks = new ArrayDeque<>();
    private final Deque<Long> rightClicks = new ArrayDeque<>();
    private boolean lastLeft, lastRight;
    private Integer savedLimit;
    private Double savedGamma;
    private ChatVisiblity savedChatVisibility;
    private boolean appliedFullbright, appliedChat, appliedHitboxes;
    private Integer savedFov;

    private static final EquipmentSlot[] ARMOR = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};

    @Override public void onInitializeClient() {
        BoxConfig.load();
        ClientTickEvents.START_CLIENT_TICK.register(this::fireworkFixed);
        ClientTickEvents.END_CLIENT_TICK.register(this::tick);
        HudRenderCallback.EVENT.register(this::render);
        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("boxpvp").executes(ctx -> {
                    Minecraft.getInstance().setScreen(new BoxMenuScreen());
                    return 1;
                })));
    }

    private void fireworkFixed(Minecraft mc) {
        if (!BoxConfig.fireworkFix || mc.player == null || mc.gameMode == null || mc.screen != null || !mc.player.isFallFlying()) return;
        InteractionHand hand = null;
        if (mc.player.getItemInHand(InteractionHand.MAIN_HAND).is(Items.FIREWORK_ROCKET)) hand = InteractionHand.MAIN_HAND;
        else if (mc.player.getItemInHand(InteractionHand.MAIN_HAND).isEmpty() && mc.player.getItemInHand(InteractionHand.OFF_HAND).is(Items.FIREWORK_ROCKET)) hand = InteractionHand.OFF_HAND;
        if (hand == null) return;
        while (mc.options.keyUse.consumeClick()) { mc.gameMode.useItem(mc.player, hand); mc.player.swing(hand); }
        mc.options.keyUse.setDown(false);
    }

    private void tick(Minecraft mc) {
        handleKey(BoxKeybinds.MENU, mc, () -> { if (mc.screen == null) mc.setScreen(new BoxMenuScreen()); });
        handleKey(BoxKeybinds.FULLBRIGHT, mc, () -> BoxConfig.fullbright = !BoxConfig.fullbright);
        handleKey(BoxKeybinds.HIDE_CHAT, mc, () -> BoxConfig.hideChat = !BoxConfig.hideChat);
        handleKey(BoxKeybinds.CROSSHAIR, mc, () -> BoxConfig.customCrosshair = !BoxConfig.customCrosshair);
        handleKey(BoxKeybinds.HITBOXES, mc, () -> BoxConfig.hitboxes = !BoxConfig.hitboxes);
        handleKey(BoxKeybinds.FPS_BOOST, mc, () -> BoxConfig.boost = !BoxConfig.boost);
        handleKey(BoxKeybinds.HUD_EDITOR, mc, () -> { if (mc.screen == null) mc.setScreen(new HudEditorScreen()); });
        handleKey(BoxKeybinds.SHOW_HUD, mc, () -> BoxConfig.hud = !BoxConfig.hud);
        handleKey(BoxKeybinds.ZOOM, mc, () -> BoxConfig.zoom = !BoxConfig.zoom);
        handleKey(BoxKeybinds.PARTICLES, mc, () -> BoxConfig.noParticles = !BoxConfig.noParticles);
        handleKey(BoxKeybinds.NO_WEATHER, mc, () -> BoxConfig.noWeather = !BoxConfig.noWeather);
        handleKey(BoxKeybinds.NO_VIGNETTE, mc, () -> BoxConfig.noVignette = !BoxConfig.noVignette);

        FpsBoost.sync(mc);
        applyVisuals(mc);
        if (BoxConfig.noParticles && mc.level != null) mc.particleEngine.clearParticles();
        if (BoxConfig.fpsLimit >= 0) mc.options.framerateLimit().set(BoxConfig.fpsLimit == 0 ? 260 : BoxConfig.fpsLimit);

        if (BoxConfig.bgThrottle && !mc.isWindowActive()) {
            if (savedLimit == null) savedLimit = mc.options.framerateLimit().get();
            mc.options.framerateLimit().set(30);
        } else if (savedLimit != null) {
            mc.options.framerateLimit().set(savedLimit); savedLimit = null;
        }

        long now = System.currentTimeMillis();
        boolean left = mc.options.keyAttack.isDown(), right = mc.options.keyUse.isDown();
        if (mc.screen == null) { if (left && !lastLeft) leftClicks.addLast(now); if (right && !lastRight) rightClicks.addLast(now); }
        lastLeft=left; lastRight=right;
        while (!leftClicks.isEmpty() && now-leftClicks.peekFirst()>1000) leftClicks.removeFirst();
        while (!rightClicks.isEmpty() && now-rightClicks.peekFirst()>1000) rightClicks.removeFirst();
        if (BoxConfig.zoom && savedFov == null) { savedFov = mc.options.fov().get(); mc.options.fov().set(30); }
        else if (!BoxConfig.zoom && savedFov != null) { mc.options.fov().set(savedFov); savedFov = null; }
    }

    private void handleKey(KeyMapping key, Minecraft mc, Runnable action) {
        while (key.consumeClick()) { if (mc.screen == null || key == BoxKeybinds.MENU) { action.run(); BoxConfig.save(); } }
    }

    private void applyVisuals(Minecraft mc) {
        if (mc.player == null) return;
        if (BoxConfig.fullbright && !appliedFullbright) { savedGamma = mc.options.gamma().get(); mc.options.gamma().set(16.0); appliedFullbright=true; }
        else if (!BoxConfig.fullbright && appliedFullbright) { mc.options.gamma().set(savedGamma == null ? 1.0 : savedGamma); savedGamma=null; appliedFullbright=false; }
        if (BoxConfig.hideChat && !appliedChat) { savedChatVisibility=mc.options.chatVisibility().get(); mc.options.chatVisibility().set(ChatVisiblity.HIDDEN); appliedChat=true; }
        else if (!BoxConfig.hideChat && appliedChat) { mc.options.chatVisibility().set(savedChatVisibility == null ? ChatVisiblity.FULL : savedChatVisibility); savedChatVisibility=null; appliedChat=false; }
        if (BoxConfig.hitboxes != appliedHitboxes) { mc.getEntityRenderDispatcher().setRenderHitBoxes(BoxConfig.hitboxes); appliedHitboxes=BoxConfig.hitboxes; }
    }

    private void render(GuiGraphics g, DeltaTracker delta) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.options.hideGui) return;
        if (BoxConfig.customCrosshair) renderCrosshair(g, mc);
        if (!BoxConfig.hud) return;
        int x=BoxConfig.hudX, y=BoxConfig.hudY, white=0xFFFFFFFF;
        if (BoxConfig.fps) { g.drawString(mc.font,"FPS: "+mc.getFps(),x,y,white); y+=11; }
        if (BoxConfig.cps) { g.drawString(mc.font,"CPS: "+leftClicks.size()+" | "+rightClicks.size(),x,y,white); y+=11; }
        if (BoxConfig.ping) { PlayerInfo info=mc.getConnection()!=null?mc.getConnection().getPlayerInfo(mc.player.getUUID()):null; if(info!=null){g.drawString(mc.font,"Ping: "+info.getLatency()+" ms",x,y,white);y+=11;} }
        if (BoxConfig.coords) { g.drawString(mc.font,String.format("XYZ: %.1f %.1f %.1f",mc.player.getX(),mc.player.getY(),mc.player.getZ()),x,y,white); y+=11; }
        if (BoxConfig.keystrokes) { g.drawString(mc.font,"W "+(mc.options.keyUp.isDown()?"■":"□")+"  A "+(mc.options.keyLeft.isDown()?"■":"□")+" S "+(mc.options.keyDown.isDown()?"■":"□")+" D "+(mc.options.keyRight.isDown()?"■":"□"),x,y,white); y+=11; }
        if (BoxConfig.armor) { y+=3; for(EquipmentSlot slot:ARMOR){ItemStack stack=mc.player.getItemBySlot(slot); if(stack.isEmpty())continue; g.renderItem(stack,x,y); if(stack.isDamageableItem()) g.drawString(mc.font,String.valueOf(stack.getMaxDamage()-stack.getDamageValue()),x+20,y+4,white); y+=18;} }
    }

    private void renderCrosshair(GuiGraphics g, Minecraft mc) {
        int cx=mc.getWindow().getGuiScaledWidth()/2, cy=mc.getWindow().getGuiScaledHeight()/2, s=BoxConfig.crosshairSize, gap=BoxConfig.crosshairGap, c=0xFFFFFFFF;
        g.fill(cx-s,cy-1,cx-gap,cy+1,c); g.fill(cx+gap,cy-1,cx+s,cy+1,c); g.fill(cx-1,cy-s,cx+1,cy-gap,c); g.fill(cx-1,cy+gap,cx+1,cy+s,c);
    }
}
