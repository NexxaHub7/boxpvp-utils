package com.luiscript.boxpvp;

import net.minecraft.client.CloudStatus;
import net.minecraft.client.GraphicsPreset;
import net.minecraft.client.Minecraft;
import net.minecraft.client.OptionInstance;
import net.minecraft.client.Options;
import net.minecraft.client.ParticleStatus;

import java.util.LinkedHashMap;
import java.util.Map;

public final class FpsBoost {

    // ---- Ajusta aqui si quieres ver mas o menos lejos ----
    private static final int RENDER_DISTANCE = 6;
    private static final int SIMULATION_DISTANCE = 5;
    // ------------------------------------------------------

    private static final Map<OptionInstance<?>, Object> BACKUP = new LinkedHashMap<>();
    private static boolean applied = false;

    private FpsBoost() {}

    private static <T> void set(OptionInstance<T> opt, T value) {
        BACKUP.putIfAbsent(opt, opt.get());
        opt.set(value);
    }

    @SuppressWarnings({"unchecked", "rawtypes"})
    private static void restore() {
        for (Map.Entry<OptionInstance<?>, Object> e : BACKUP.entrySet()) {
            ((OptionInstance) e.getKey()).set(e.getValue());
        }
        BACKUP.clear();
    }

    /** Aplica o revierte los ajustes segun BoxConfig.boost. */
    public static void sync(Minecraft mc) {
        if (BoxConfig.boost == applied) return;

        if (BoxConfig.boost) {
            apply(mc.options);
        } else {
            restore();
        }

        applied = BoxConfig.boost;
    }

    private static void apply(Options o) {
        // Distancias
        set(o.renderDistance(), RENDER_DISTANCE);
        set(o.simulationDistance(), SIMULATION_DISTANCE);
        set(o.entityDistanceScaling(), 0.5);

        // Graficos
        set(o.graphicsPreset(), GraphicsPreset.FAST);
        set(o.cloudStatus(), CloudStatus.OFF);
        set(o.particles(), ParticleStatus.MINIMAL);
        set(o.ambientOcclusion(), false);

        // Sombras / calidad
        set(o.entityShadows(), false);
        set(o.biomeBlendRadius(), 0);
        set(o.mipmapLevels(), 0);

        // Framerate
        set(o.framerateLimit(), 260);
        set(o.enableVsync(), false);

        // Efectos
        set(o.bobView(), false);
        set(o.screenEffectScale(), 0.0);
        set(o.fovEffectScale(), 0.0);
        set(o.darknessEffectScale(), 0.0);
        set(o.damageTiltStrength(), 0.0);
        set(o.glintSpeed(), 0.0);
        set(o.glintStrength(), 0.0);
        set(o.hideLightningFlash(), true);
    }
}