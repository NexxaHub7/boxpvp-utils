package com.luiscript.boxpvp;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.input.MouseButtonEvent;
import net.minecraft.network.chat.Component;

public class HudEditorScreen extends Screen {
    private boolean dragging;
    private int grabX, grabY;
    public HudEditorScreen(){ super(Component.literal("HUD Editor")); }
    @Override public void renderBackground(GuiGraphics g, int mouseX, int mouseY, float delta) { g.fill(0,0,width,height,0xB0101118); }
    @Override public void render(GuiGraphics g,int mouseX,int mouseY,float delta){
        renderBackground(g,mouseX,mouseY,delta);
        g.fill(30,25,width-30,height-25,0xEE151923);
        g.drawString(font,"HUD EDITOR",45,40,0xFFFFFFFF);
        g.drawString(font,"Arrastra el bloque para mover el HUD. ESC = salir",45,55,0xFF9FA8B7);
        int x=BoxConfig.hudX,y=BoxConfig.hudY;
        int bx=Math.max(40,Math.min(width-180,x)), by=Math.max(80,Math.min(height-50,y));
        g.fill(bx-5,by-5,bx+150,by+25,0xAA202A38);
        g.drawString(font,"FPS: "+Minecraft.getInstance().getFps()+"  •  HUD",bx,by,0xFFFFFFFF);
        g.drawString(font,"X: "+BoxConfig.hudX+"  Y: "+BoxConfig.hudY,45,height-42,0xFF9FA8B7);
        super.render(g,mouseX,mouseY,delta);
    }
    @Override public boolean mouseClicked(MouseButtonEvent event, boolean doubleClick){
        double mx=event.x(), my=event.y(); int button=event.button();
        if(button==0 && mx>=BoxConfig.hudX-5 && mx<=BoxConfig.hudX+150 && my>=BoxConfig.hudY-5 && my<=BoxConfig.hudY+25){dragging=true;grabX=(int)mx-BoxConfig.hudX;grabY=(int)my-BoxConfig.hudY;return true;} return super.mouseClicked(event,doubleClick);
    }
    @Override public boolean mouseDragged(MouseButtonEvent event,double dx,double dy){ if(dragging){BoxConfig.hudX=(int)event.x()-grabX;BoxConfig.hudY=(int)event.y()-grabY;BoxConfig.save();return true;} return super.mouseDragged(event,dx,dy); }
    @Override public boolean mouseReleased(MouseButtonEvent event){dragging=false;return super.mouseReleased(event);}
}
